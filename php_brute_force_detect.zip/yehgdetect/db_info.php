<?php

//Modify the following according to your database server, username, password, database name, database table name

$db_server = 'localhost';
$db_user_login = 'username';
$db_user_pass = 'password';
$db_name = 'test';
$db_table = 'yehgdetect';

?>
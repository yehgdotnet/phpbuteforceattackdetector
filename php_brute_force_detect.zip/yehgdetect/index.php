<?php
/*************************************************************

PHP BruteForce Attack Detector - beta

June 2008 (c) Aung Khant 
http://yehg.net/lab
License GPL

*************************************************************/

require_once("config.php");
require_once("db_info.php");
require_once("database.php");

if($isdisable==0)
{
// to fool most bruce force tools
header("HTTP/1.1 200 OK");

$db = new database();
$db->connect();

$today = date("Y-m-j,G");

$min = date("i");
$r = substr(date("i"),0,1);
$m =  substr(date("i"),1,1);
$minute = 0;

if($m>=0 && $m<=5){$m=5;$minute = (int)$r.$m;}else if($m>5){$m=0;$r++;$r=$r*10;$minute = $r;}

$ip = $_SERVER["REMOTE_ADDR"];
$forward_ip = 'None';
if(isset($_SERVER["HTTP_X_FORWARDED_FOR"]))$forward_ip = 'FOWARD_IP: '.$_SERVER["HTTP_X_FORWARDED_FOR"];
if(isset($_SERVER["HTTP_VIA"]))$forward_ip = $forward_ip.' VIA: '.$_SERVER["HTTP_VIA"];

$useragent= $_SERVER["HTTP_USER_AGENT"];	
$userlan= $_SERVER["HTTP_ACCEPT_LANGUAGE"];

//Extract , check bruteforce, deny
$b_info = "SELECT notify4today,COUNT(*) as hits FROM $db_table WHERE `today`='$today' AND `minute`='$minute' GROUP By `today` ";
$bres_info = $db->__query($b_info);
$store_req = mysql_fetch_array($bres_info,MYSQL_ASSOC);

//echo 'HITs '. $store_req["hits"].'<br>';

if($store_req["hits"]>= $max_request)
{
	$message = "
Date: $today:$min
IP: $ip
Forward Proxy : $forward_ip
Usergent: $useragent
UserLanguage: $userlan
	";
	$subject = "Possible Brute Force Attack @ $today:$min";

	$db->__query("UPDATE $db_table SET `isnotify`='1' WHERE `today`='$today' AND `minute`='$minute'");
	$db->__query("UPDATE $db_table SET `notify4today`='1' WHERE `today`='$today' AND `minute`='$minute'");
	$db->disconnect();	
	
	if($store_req["notify4today"]=='0' && $emailnotify==1)
	{

		@mail($to, $subject, $message, $headers);	
	}

	if($logfile==1 && is_writeable("l0gz"))
	{
		//Must be random
		$logfile = $today.','.$min.'@'.substr(md5(time()),12);
		$attacklog = $subject."\n".$message;
		@file_put_contents('l0gz/'.$logfile,$attacklog);
	}

	if($store_req["notify4today"]=='0' && $logsys==1)
	{

		$access = date("Y/m/d H:i:s");
    	@syslog(LOG_NOTICE, "BruteForce Attack at $access From {$_SERVER['REMOTE_ADDR']} ({$_SERVER['HTTP_USER_AGENT']}) Please ban this IP asap.");	
	}
	
	if($anti_attack==1)
	{
		ini_set("max_execution_time",$sleep_time*60+2);
		sleep($sleep_time*60);			
	}	
		
	/* 
	Further implementation: 
	
	Discuss with your server admin and ask him how you can apply talking to server IDS.

	*/	
	die("<h2>Page Not Found</h2><p>If you think the page should exist, please let us know why you get here.<br> If our link got broken, we'd fix it asap.</p>");
	//die("<h1 style='color:red'>BruteForce Attack Detected! Your IP will be banned immediately after talking to server IDS.</h1>");
	 
}

$b1_info = "SELECT notify4today FROM $db_table WHERE `today`='$today'";
$b1res_info = $db->__query($b1_info);
$store1_req = mysql_fetch_array($b1res_info,MYSQL_ASSOC);

if($store1_req["notify4today"]==1)
{
	$db->__query("INSERT INTO $db_table (`today`,`minute`,`ip`,`forward_ip`,`useragent`,`userlan`,`notify4today`) VALUES ('$today','$minute','$ip','$forward_ip','$useragent','$userlan','1');");
}
else 
{
	$db->__query("INSERT INTO $db_table (`today`,`minute`,`ip`,`forward_ip`,`useragent`,`userlan`) VALUES ('$today','$minute','$ip','$forward_ip','$useragent','$userlan');");	
}

$db->disconnect();


?>
<h2>Page Not Found</h2>
<p>If you think the page should exist, please let us know why you get here.<br> If our link got broken, we'd fix it asap.</p>
<!--

<?

$az = array("a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","{","}","[","]","!","@","1","2","3","4","5","6","7","8","9","0","~","!","#","$","%","^","&","*","()",")","-","+","/","\\",".",",","_","|");

$n = mt_rand(1,count($az)-1);

function make_seed()
{
  list($usec, $sec) = explode(' ', microtime());
  return (float) $sec + ((float) $usec * 100000);
}
mt_srand(make_seed());
$randval = mt_rand();

$i=0;
foreach($az as $a)
{
	if($i>$n){break;}
	echo sha1($a).$randval;
	$ln = mt_rand(1,3);	
	if($ln==1){echo "\n".mt_rand($ln,$randval)."\n";}
	else if($ln==3){echo "\n".mt_rand($ln,$randval)."\n\n";}
	else {echo "\n".mt_rand($ln,$randval);}
	$i++;
}
?>

-->
<? } ?>
<?

class database {

	function this(){
		return $this->db;
	}

	function connect()
	{
		require("db_info.php");
		$this->db = @mysql_connect($db_server, $db_user_login, $db_user_pass);
		if(!$this->db){
			$this->fatal_error("Couldn't connect to database server");
			return false;
		}

		if(!mysql_select_db($db_name, $this->db)) {
			$this->fatal_error("Couldn't select the database: " . $db_name);
			return false;
		}

		return true;
	}

	function disconnect() {
		@mysql_close($this->db);
	}

	function __query($query){

		if(!$this->db){
			$this->fatal_error("No active db connection");
			return false;
		}

		$result = @mysql_query($query, $this->db);
		if(!$result)
			$this->fatal_error("mySQL query error: " . mysql_error());

		return $result;

	}

	function SetQuery($query){
		if(!$results = $this->__query($query))
			return false;

		$newid = @mysql_insert_id($this->db);

		if($newid){
			return $newid;
		} else {
			return @mysql_affected_rows($this->db);
		}
	}

	function GetQuery($query){
		if(!$results = $this->__query($query))
			return false;

		$ret = array();

		while($row = @mysql_fetch_assoc($results))
			$ret[] = $row;

		return $ret;
	}

	function fatal_error($the_error) {
		$the_error .= "<br />mySQL error: " . mysql_error() . "<br />";
		$the_error .= "mySQL error code: " . mysql_errno() . "<br />";

		//@header("HTTP/1.0 403 Forbidden");
		echo $the_error;
		//exit;
	}
}
?>

<?
mb_http_input("utf-8");
mb_http_output("utf-8");

/***** [Development OR Production Time] ****/

// set 2047 for development, 0 for production
$dev_time = 0;
error_reporting($dev_time);

/***** [/Development OR Deployment Time] ****/


/********* YOUR CONFIGURATION STARTS HERE ************/

// Whether or not disabling PHP-BruteForce-Attack Detector
// 1 to disable, 0 to enable
$isdisable = 0;

/***** [Constraint Info] ****/
// If 404 requests reach over max_request, notify you
$max_request = 100; // per 5 minutes

/***** [/Constraint Info] ****/

/***** [Notify Info] ****/

// your/your server admin's email address
$to      = 'nobody@yehg.net';
$headers = 'From: siteguard@yehg.net' . "\r\n" .    	   
    		'X-Mailer: yehg.net BruceForce Attack Detector';
    		
// if attack occurs, mail you / your server admin
// 0 to no emailing 
$emailnotify = 1;
// Log attacks in file, 1 to yes, 0 to no
$logfile = 1;
// Log attacks in system log mechanism or server, 1 to yes, 0 to no
// You should discuss with your server admin to enable 
// or you tend to mess up
$logsys = 0;

/***** [/Notify Info] ****/

/***** [Anti-Attack] ****/
// if set to 1, sleep the application for several minutes, causing attackers' tools timing out
// be careful, it may cause DOS to your web server 
$anti_attack = 0;
$sleep_time = 5; // minute
/***** [/Anti-Attack] ****/


?>
